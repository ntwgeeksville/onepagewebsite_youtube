// Wait for all elements on the page to be loaded before running javascript
document.addEventListener("DOMContentLoaded", function() {

    // Grab elements
    let hamburger = document.getElementById('hamburger');
    let hmenu = document.getElementById('main-menu');
    let hmenuItems = document.querySelectorAll('.menuItem');

    // Menu Btn
    hamburger.addEventListener('click', function() {
        hmenu.classList.toggle('active');
    })

    // Close menu on menu selection
    hmenuItems.forEach(btn => btn.addEventListener('click', function(e) {

        const hamburgerContainer = document.getElementById('hamburger-container');
        let display = window.getComputedStyle(hamburgerContainer).display;

        if (display != "none") {
            hmenu.classList.toggle('active');
        }

    }))

})